using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    // Se crean las variables de los objetos
   public GameObject Verde;
   public GameObject RojoIzq;
   public GameObject RojoDer;
   public GameObject NaranjaIzq;
   public GameObject NaranjaDer;
    public GameObject Bola;

    void OnTriggerEnter2D(Collider2D other) 
    {
        // Se crean las condiciones para que al tocar el objeto se muestre cuántos puntos consigues dependiendo del objeto que se toque
        if (gameObject.name == "Verde")
        {
            Debug.Log("Ganaste 10 puntos");
        }
        else if (gameObject.name == "RojoIzq")
        {
            Debug.Log("Ganaste 1 punto");
        }
        else if (gameObject.name == "RojoDer")
        {
            Debug.Log("Ganaste 1 punto");
        }
        else if (gameObject.name == "NaranjaIzq")
        {
            Debug.Log("Ganaste 5 puntos");
        }
        else if (gameObject.name == "NaranjaDer")
        {
            Debug.Log("Ganaste 5 puntos");
        }
    }

    
    
    void Start()
    {
     
    // Update is called once per frame
    void Update()
    {
        
    }
    }
}